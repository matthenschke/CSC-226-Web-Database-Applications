<?php
function login()
{
	 $db = new mysqli('localhost', 'henschke', 'matthew7430', 'pageVisits');
	return $db;
	}
?>